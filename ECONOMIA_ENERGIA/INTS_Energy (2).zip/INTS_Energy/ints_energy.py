# ---------------------------------------------------------
# Desenvolvido por: Fabio Stefano de Figueiredo
# Hospital INTS - Suporte Técnico de T.I.
# Versão: 5.2 - Março/2026 (Correção de Loop e Tarefa Global)
# ---------------------------------------------------------
import customtkinter as ctk
import datetime
import os
import time
import ctypes
import psutil

# DPI Awareness
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(1)
except:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except:
        pass

PATH_FOLDER = r"C:\INTS_Energy"
PATH_CONFIG = os.path.join(PATH_FOLDER, "config.txt")
PATH_LOG = os.path.join(PATH_FOLDER, "log_sistema.txt")

def escrever_log(mensagem):
    try:
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        with open(PATH_LOG, "a") as f:
            f.write(f"[{timestamp}] {mensagem}\n")
    except:
        pass

def limpar_log():
    if not os.path.exists(PATH_FOLDER): os.makedirs(PATH_FOLDER)
    with open(PATH_LOG, "w") as f:
        f.write(f"--- Log Iniciado em {datetime.datetime.now().strftime('%d/%m/%Y')} ---\n")

class InterfaceAviso(ctk.CTk):
    def __init__(self, diff_minutos, t_adiar, hora_desliga):
        super().__init__()
        self.t_adiar = t_adiar
        self.hora_desliga = hora_desliga
        self.tempo_restante = int(diff_minutos * 60) if diff_minutos > 0 else 30
        
        self.attributes("-fullscreen", True)
        self.attributes("-topmost", True)
        self.configure(fg_color="#2D5A27")
        
        self.content = ctk.CTkFrame(self, fg_color="transparent")
        self.content.place(relx=0.5, rely=0.5, anchor="center")

        self.label_titulo = ctk.CTkLabel(self.content, text="AVISO DE ECONOMIA - INTS", font=("Segoe UI", 55, "bold"), text_color="white")
        self.label_titulo.pack()

        self.label_msg = ctk.CTkLabel(self.content, text=f"O computador será desligado às: {self.hora_desliga}", font=("Segoe UI", 28), text_color="white")
        self.label_msg.pack(pady=10)

        self.label_timer = ctk.CTkLabel(self.content, text="", font=("Segoe UI", 150, "bold"), text_color="#ADFF2F")
        self.label_timer.pack(pady=20)

        self.btn_adiar = ctk.CTkButton(self.content, 
                                       text=f"ESTOU USANDO O COMPUTADOR (Adiar {t_adiar} min)", 
                                       command=self.adiar, 
                                       font=("Segoe UI", 24, "bold"), 
                                       fg_color="white", 
                                       text_color="#2D5A27", 
                                       hover_color="#EEEEEE",
                                       height=85, width=550, corner_radius=15)
        self.btn_adiar.pack(pady=30)
        self.atualizar_timer()

    def atualizar_timer(self):
        if self.tempo_restante > 0:
            mins, secs = divmod(self.tempo_restante, 60)
            self.label_timer.configure(text=f"{mins:02d}:{secs:02d}")
            self.tempo_restante -= 1
            self.after(1000, self.atualizar_timer)
        else:
            escrever_log("Tempo esgotado. Comando de desligamento enviado.")
            os.system("shutdown /s /f /t 0")

    def adiar(self):
        try:
            with open(PATH_CONFIG, "r") as f:
                linhas = f.readlines()
            
            h_alvo_str = linhas[0].strip()
            minutos_para_somar = int(linhas[2].strip())
            
            agora = datetime.datetime.now()
            alvo_atual = datetime.datetime.combine(agora.date(), 
                         datetime.datetime.strptime(h_alvo_str, "%H:%M").time())
            
            nova_hora_obj = alvo_atual + datetime.timedelta(minutes=minutos_para_somar)
            if nova_hora_obj < agora:
                nova_hora_obj = agora + datetime.timedelta(minutes=minutos_para_somar)

            nova_hora_str = nova_hora_obj.strftime("%H:%M")
            
            with open(PATH_CONFIG, "w") as f:
                f.write(f"{nova_hora_str}\n{linhas[1].strip()}\n{linhas[2].strip()}")
            
            # ATUALIZA TAREFA GLOBAL (Importante: /ru "System")
            os.system(f'schtasks /create /tn "INTS_Seguranca" /tr "shutdown /s /f /t 0" /sc once /st {nova_hora_str} /f /rl highest /ru "System"')

            escrever_log(f"AÇÃO: Adiado de {h_alvo_str} para {nova_hora_str} (+{minutos_para_somar} min)")
            self.destroy()
        except Exception as e:
            escrever_log(f"Erro ao adiar: {e}")
            self.destroy()

def monitorar():
    # 1. LÓGICA ANTI-PILHA REFORÇADA
    # Primeiro tenta o comando nativo do Windows (força bruta)
    # Isso mata qualquer 'ints_energy.exe' que já esteja rodando antes de iniciar este.
    try:
        os.system('taskkill /F /IM ints_energy.exe /FI "PID ne %d"' % os.getpid())
    except:
        pass

    # Segundo: Usa o psutil para garantir (lógica fina)
    meu_pid = os.getpid()
    try:
        for proc in psutil.process_iter(['pid', 'name']):
            if proc.info['name'] == "ints_energy.exe" and proc.info['pid'] != meu_pid:
                proc.kill()
    except:
        pass

    limpar_log()
    escrever_log("Serviço Iniciado. Sincronizando tarefa global...")

    proxima_abertura_permitida = datetime.datetime.now()

    while True:
        try:
            if os.path.exists(PATH_CONFIG):
                with open(PATH_CONFIG, "r") as f:
                    content = f.read().splitlines()
                
                if len(content) >= 3:
                    h_alvo_str = content[0]
                    t_aviso = int(content[1])
                    t_adiar = int(content[2])

                    agora = datetime.datetime.now()
                    alvo = datetime.datetime.combine(agora.date(), 
                           datetime.datetime.strptime(h_alvo_str, "%H:%M").time())
                    
                    if alvo < agora - datetime.timedelta(minutes=10):
                        alvo += datetime.timedelta(days=1)
                    
                    diff_minutos = (alvo - agora).total_seconds() / 60

                    # LOG DE CONTROLE: Só escreve no log a cada 1 minuto para não encher o arquivo
                    if int(agora.second) == 0: 
                        escrever_log(f"STATUS: Alvo={h_alvo_str} | Faltam: {diff_minutos:.1f} min")

                    # DISPARO COM TRAVA ANTI-LOOP
                    if -1.0 <= diff_minutos <= t_aviso: # Reduzi a margem para -1.0 para ser mais preciso
                        if agora >= proxima_abertura_permitida:
                            escrever_log(f"DISPARO: Janela aberta para o alvo {h_alvo_str}")
                            app = InterfaceAviso(diff_minutos, t_adiar, h_alvo_str)
                            app.mainloop()
                            
                            # A TRAVA: Só deixa abrir de novo após o tempo de aviso + 1 minuto
                            # Se o aviso é 3 min e adiar 2, ele NÃO abre imediatamente.
                            proxima_abertura_permitida = datetime.datetime.now() + datetime.timedelta(minutes=t_aviso + 1)
                            escrever_log(f"BLOQUEIO: Próxima janela permitida só após {proxima_abertura_permitida.strftime('%H:%M:%S')}")
        
        except Exception as e:
            escrever_log(f"Erro: {e}")
        
        time.sleep(5)

if __name__ == "__main__":
    monitorar()