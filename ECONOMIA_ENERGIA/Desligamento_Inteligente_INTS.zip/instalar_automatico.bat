@echo off
:: ===========================================================
:: INSTALADOR AUTOMATICO - ECONOMIA DE ENERGIA INTS
:: COPIA PARA O C:\ E LIMPA O RASTRO DA ORIGEM
:: ===========================================================
title Instalador INTS - Fabio Stefano

set DESTINO=C:\Desligamento_Inteligente
set ORIGEM=%~dp0

:: 1. Se ja estiver rodando do C:, apenas abre o HTA
if "%ORIGEM%"=="%DESTINO%\" (
    start "" "%DESTINO%\Instalador.hta"
    exit
)

:: 2. Se estiver em outro lugar (ex: Downloads), faz a migração
echo Configurando ambiente no C:\...
if not exist "%DESTINO%" mkdir "%DESTINO%"
xcopy /e /i /y "%ORIGEM%*" "%DESTINO%\"

:: 3. Abre o HTA que ja esta na pasta correta
start "" "%DESTINO%\Instalador.hta"

:: 4. MENSAGEM DE LIMPEZA (Opcional)
echo Instalacao preparada. Limpando arquivos temporarios...

:: 5. LIMPEZA TOTAL DA ORIGEM (Exceto o aviso)
echo ======================================================= > "%ORIGEM%AVISO_LEIA-ME.txt"
echo AVISO: ARQUIVOS MOVIDOS PARA O DRIVE C:\ >> "%ORIGEM%AVISO_LEIA-ME.txt"
echo ======================================================= >> "%ORIGEM%AVISO_LEIA-ME.txt"
echo Por questoes de seguranca e funcionamento, este sistema >> "%ORIGEM%AVISO_LEIA-ME.txt"
echo foi instalado em: C:\Desligamento_Inteligente >> "%ORIGEM%AVISO_LEIA-ME.txt"
echo. >> "%ORIGEM%AVISO_LEIA-ME.txt"
echo Voce ja pode apagar esta pasta de origem se desejar. >> "%ORIGEM%AVISO_LEIA-ME.txt"

:: Pequena pausa para o Windows liberar os arquivos
timeout /t 2 /nobreak >nul

:: Força a exclusão de todos os outros arquivos da pasta de origem
:: /F força a exclusão de arquivos somente leitura
:: /Q modo silencioso
for %%f in ("%ORIGEM%*.*") do (
    if not "%%~nxf"=="AVISO_LEIA-ME.txt" (
        del /f /q "%%f" 2>nul
    )
)

exit