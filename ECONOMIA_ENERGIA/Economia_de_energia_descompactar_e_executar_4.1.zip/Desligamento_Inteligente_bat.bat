@echo off
:: ===========================================================
:: SISTEMA DE ECONOMIA DE ENERGIA INTS
:: DESENVOLVIDO POR: FABIO STEFANO DE FIGUEIREDO
:: ===========================================================
setlocal enabledelayedexpansion

:: Navega até a pasta correta
cd /d "C:\Desligamento_Inteligente"

:AGUARDAR_HORARIO
:: 1. Lê o horário alvo (1ª linha) e o intervalo (2ª linha)
set /p horario_alvo=<"C:\Desligamento_Inteligente\config.txt"
for /f "skip=1 delims=" %%a in (C:\Desligamento_Inteligente\config.txt) do set intervalo_min=%%a

:: Pega a hora atual e garante o formato correto
set "hora_agora=%time: =0%"
set "hora_atual=%hora_agora:~0,5%"

echo [!] Vigilancia Ativa: Aguardando dar %horario_alvo% (Agora: %hora_atual%)

:: 2. Compara se chegou a hora
if "%hora_atual%"=="%horario_alvo%" (
    echo [!] HORARIO ATINGIDO! Iniciando ciclo de avisos...
    goto CICLO_DE_AVISOS
)

timeout /t 30 /nobreak >nul
goto AGUARDAR_HORARIO


:CICLO_DE_AVISOS
:: 3. Abre o HTA e ESPERA o médico fechar
:: (Aqui ele usa o nome do seu HTA de alerta)
start /wait "" "Desligamento_Inteligente_hta.hta"

:: 4. LÓGICA DINÂMICA DE INTERVALO
:: Lê o intervalo novamente para caso o técnico tenha alterado sem reiniciar o PC
for /f "skip=1 delims=" %%a in (C:\Desligamento_Inteligente\config.txt) do set intervalo_min=%%a

:: Converte minutos para segundos (Minutos * 60)
set /a segundos_espera=%intervalo_min% * 60

echo [!] O aviso foi fechado. Aguardando %intervalo_min% minutos para insistir...
timeout /t %segundos_espera% /nobreak

:: Volta para o ciclo de avisos
goto CICLO_DE_AVISOS