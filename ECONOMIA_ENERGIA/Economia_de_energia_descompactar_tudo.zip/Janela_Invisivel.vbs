' ===========================================================
' SISTEMA DE ECONOMIA DE ENERGIA INTS
' DESENVOLVIDO POR: FABIO STEFANO DE FIGUEIREDO
' CONTATO: fabio.figueiredo@ints.org.br
' CONTATO PESSOAL: fabio.sf10@hotmail.com
' ===========================================================

Set WshShell = CreateObject("WScript.Shell")
' Abre o BAT que gerencia o loop
WshShell.Run "C:\Desligamento_Inteligente\Desligamento_Inteligente_bat.bat", 0, False

' Loop para garantir que a janela fique no topo sempre que abrir
Do
    ' Espera um pouco para não sobrecarregar o processador
    WScript.Sleep 2000 
    ' Tenta trazer a janela para a frente pelo título exato
    Ativo = WshShell.AppActivate("SISTEMA DE ECONOMIA DE ENERGIA - INTS")
    If Ativo Then
        ' Se a janela existe, ele envia um comando neutro (Alt) para forçar o foco
        WshShell.SendKeys "%"
    End If
Loop