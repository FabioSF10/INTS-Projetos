@echo off
:: ===========================================================
:: SISTEMA DE ECONOMIA DE ENERGIA INTS
:: DESENVOLVIDO POR: FABIO STEFANO DE FIGUEIREDO
:: CONTATO: fabio.figueiredo@ints.org.br
:: CONTATO PESSOAL: fabio.sf10@hotmail.com
:: TODOS OS DIREITOS RESERVADOS © 2026
:: ===========================================================
setlocal enabledelayedexpansion

:: Navega até a pasta correta
cd /d "C:\Desligamento_Inteligente"

:AGUARDAR_HORARIO
:: 1. Lê o horário alvo do arquivo config.txt
set /p horario_alvo=<"C:\Desligamento_Inteligente\config.txt"
:: Pega a hora atual e garante que horas menores que 10 tenham o zero (ex: 02:39 em vez de  2:39)
set "hora_agora=%time: =0%"
set "hora_atual=%hora_agora:~0,5%"

echo [!] Vigilancia Ativa: Aguardando dar %horario_alvo% (Agora: %hora_atual%)

:: 2. Compara se chegou a hora
if "%hora_atual%"=="%horario_alvo%" (
    echo [!] HORARIO ATINGIDO! Iniciando ciclo de avisos...
    goto CICLO_DE_AVISOS
)

:: Espera 30 segundos e verifica o relógio de novo
timeout /t 30 /nobreak >nul
goto AGUARDAR_HORARIO


:CICLO_DE_AVISOS
:: 3. Abre o HTA e ESPERA o médico fechar
start /wait /max "" "Desligamento_Inteligente_hta.hta"

:: 4. Se o médico não desligou e apenas fechou o HTA, espera 20 min (1200 seg)
echo [!] O aviso foi fechado. Aguardando 20 minutos para insistir...
timeout /t 1200 /nobreak

:: Volta para o ciclo de avisos (ele continuará insistindo até o PC desligar)
goto CICLO_DE_AVISOS