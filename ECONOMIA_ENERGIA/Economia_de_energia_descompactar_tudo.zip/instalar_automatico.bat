@echo off
:: ===========================================================
:: INSTALADOR AUTOMATICO - ECONOMIA DE ENERGIA INTS
:: COPIA PARA O C:\ E LIMPA O RASTRO DA ORIGEM
:: ===========================================================
title Instalador INTS - Fabio Stefano

set DESTINO=C:\Desligamento_Inteligente
set ORIGEM=%~dp0

:: 1. Se ja estiver rodando do C:, apenas abre o HTA
if "%ORIGEM%"=="%DESTINO%\" (
    start mshta.exe "%DESTINO%\Instalador.hta"
    exit
)

:: 2. Se estiver em outro lugar (ex: Downloads), faz a migração
echo Configurando ambiente no C:\...
if not exist "%DESTINO%" mkdir "%DESTINO%"
xcopy /e /i /y "%ORIGEM%*" "%DESTINO%\"

:: 3. Abre o HTA forçando o motor do Windows (MSHTA)
echo Iniciando interface...
start mshta.exe "%DESTINO%\Instalador.hta"

:: 4. Popup Visual de Aviso (Substitui o susto do sumiço)
set "MSG=Os arquivos foram movidos para C:\Desligamento_Inteligente para garantir o funcionamento do sistema. Esta pasta de origem ja pode ser apagada."
msg * "%MSG%" 2>nul || powershell -Command "Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show('%MSG%', 'SISTEMA INTS')"

:: 5. LIMPEZA TOTAL DA ORIGEM (Exceto o aviso TXT por segurança)
echo ======================================================= > "%ORIGEM%AVISO_LEIA-ME.txt"
echo AVISO: ARQUIVOS MOVIDOS PARA O DRIVE C:\ >> "%ORIGEM%AVISO_LEIA-ME.txt"
echo. >> "%ORIGEM%AVISO_LEIA-ME.txt"
echo Sistema instalado em: C:\Desligamento_Inteligente >> "%ORIGEM%AVISO_LEIA-ME.txt"

timeout /t 2 /nobreak >nul

for %%f in ("%ORIGEM%*.*") do (
    if not "%%~nxf"=="AVISO_LEIA-ME.txt" (
        del /f /q "%%f" 2>nul
    )
)
exit